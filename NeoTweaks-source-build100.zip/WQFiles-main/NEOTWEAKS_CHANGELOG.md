# NeoTweaks experimental fork — build 89

- Renamed the app display name to NeoTweaks.
- Added a Tweak Lab card to the New Design home screen.
- Tweak Lab currently opens the existing Apps / App Data manager; this reuses tested upstream functionality rather than claiming unsupported SpringBoard writes.
- Kept the upstream bundle identifier and App Group unchanged to preserve the access setup.
- Disabled upstream update checks in this fork so it cannot recommend replacing NeoTweaks with an upstream WQ Files IPA.
- Kept upstream GPL-3.0-or-later license and attribution.

## Not implemented yet

- SpringBoard icon replacement or theming.
- Writing to root-owned System Data.
- Arbitrary changes to system frameworks or signed resources.
- IPA signing. Build and device validation require macOS with Xcode Command Line Tools and a signing workflow.

## Build 90 — Tweak Lab workspace

- Tweak Lab now opens its own screen instead of redirecting straight to App Data.
- Added a functional local theme workspace under the app's Documents directory.
- Added creation of a `Starter` theme pack with an `Icons` folder and a versioned `theme.json` manifest.
- Added a browser entry to inspect and manage local theme-pack files using WQ Files' existing file browser.
- Added a direct entry to the existing App Data manager.
- Explicitly labels the theme pack as a template: it does not apply icons to SpringBoard.

## Build 91 — theme pack validation
- Added a Tweak Lab action that scans local theme-pack folders and validates `theme.json` JSON structure, the icon directory path, and referenced PNG filenames.
- Rejects absolute and parent-traversal icon directory paths during validation.
- Reports missing manifests, missing icon folders, malformed entries and missing PNG files.
- Validation is read-only and does not install icons or modify SpringBoard.


## Build 92 — icon image import
- Added an icon-image import flow to Tweak Lab using the iOS document picker (PNG and JPEG).
- Converts imported artwork to PNG and stores it inside the selected local theme pack's `Icons/` directory.
- Prompts for the target app's exact bundle identifier and updates the pack's `theme.json` mapping.
- Replaces an existing mapping for the same bundle ID instead of adding duplicates.
- Clearly reports that this is local theme-pack preparation only; it does not install icons or modify SpringBoard.
- Updated the app build number to 92.


## Build 94 — icon previews
- Added a dedicated scrollable preview screen for icon mappings in a local theme pack.
- Theme Manager rows now use the first available mapped icon as their thumbnail, falling back to the stack symbol when no image is available.
- Preview loading validates relative icon-directory and filename components before reading images.
- Preview is read-only and does not apply icons to installed apps or SpringBoard.
- Updated the app build number to 94.


## Build 95 — theme ZIP import and export
- Added export of a selected local theme pack as a ZIP using the existing WQArchive writer.
- Added import of ZIP archives through the iOS document picker.
- Imports extract into a temporary directory, require exactly one theme folder and a valid JSON manifest, and choose a non-conflicting destination name.
- Uses the existing archive extractor, which rejects unsafe traversal paths and unsupported/encrypted entries.
- Imported packs are still local templates; importing or exporting does not apply icons to SpringBoard.
- Updated the app build number to 95.


## Build 96 — theme management improvements
- Added editing of a theme pack's display name and description in `theme.json`.
- Added duplication of a theme pack, including its icon assets, with a new folder name and updated manifest name.
- Added collision and path-component checks before duplication.
- Corrected `CFBundleExecutable` to match the executable produced by `build.sh` (`WQFiles`), so the app bundle metadata and build output agree.
- These actions manage local theme-pack files only; they do not apply icons to SpringBoard.


## Build 97 — App Preferences Explorer

- Added a dedicated Preferences Explorer entry in Tweak Lab.
- Reuses the existing app-container scanner and WQ Files directory browser.
- Creates a fresh app backup before opening the selected app's `Library/Preferences` folder.
- Opens only the selected app's own accessible preferences directory; missing or inaccessible folders are reported without attempting a write.
- Existing plist editor behavior remains responsible for format-aware edits and verified, backup-first saves.
- Does not modify SpringBoard, system frameworks, System Data, or other apps' containers.


## Build 98 — WQ-permission-only tools hub

- Removed the theme-pack workspace, icon import, theme manager and preview UI from the active app.
- Replaced Tweak Lab with a WQ Tweaks capability hub for App Data, Preferences Editor, Cache Cleaner, App Groups, Extension Data, Internal Daemons, System Groups and System Data.
- Reused existing WQ Files controllers and file access checks; no new sandbox permissions or exploit behavior were added.
- System Data is explicitly opened read-only. Internal Daemon navigation warns about the potentially long initial scan.
- Updated README to document actual supported operations and access limitations.
- Bumped CFBundleVersion to 98.
- Native iOS compilation and device testing still require macOS/Xcode.


## Build 99 — access diagnostics
- Added a read-only Access Diagnostics screen to the WQ Tweaks hub.
- Reports the detected iOS version, System Data listing result, WQ system-area capability check, and whether App Group / Extension Data parent directories can be listed.
- Explicitly distinguishes parent listing from child-container access and does not infer write permissions.
- Does not scan Internal Daemons automatically, avoiding a potentially lengthy first scan.
- Bumped CFBundleVersion to 99.
- No new sandbox permissions or system-write behavior added.


## Build 100 — GitHub IPA build pipeline

- Added a GitHub Actions workflow on `macos-15` that runs the full existing preflight and iOS arm64 build through `build.sh`.
- Manual runs publish a downloadable `NeoTweaks-build100.ipa` workflow artifact.
- Pushing a tag named `neotweaks-v*` also attaches the IPA to a GitHub Release.
- The workflow uses the repository's existing ad-hoc signing step; it does not create an Apple provisioning profile or grant entitlements beyond the source project's declared App Group. The IPA still needs a compatible signing/install path and on-device validation.
- Bumped `CFBundleVersion` to 100.
- No additional sandbox permissions, system-write behavior, or SpringBoard modifications were added.
