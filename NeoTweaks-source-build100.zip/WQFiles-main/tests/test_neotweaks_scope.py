from pathlib import Path
import plistlib
import unittest

ROOT = Path(__file__).resolve().parents[1]

class NeoTweaksScopeTests(unittest.TestCase):
    def test_build_number_is_100(self):
        with (ROOT / 'Info.plist').open('rb') as f:
            info = plistlib.load(f)
        self.assertEqual(info['CFBundleVersion'], '100')

    def test_tweak_hub_routes_only_to_existing_wq_features(self):
        source = (ROOT / 'main.m').read_text()
        self.assertIn('Preferences Editor', source)
        self.assertIn('WQAppsViewController alloc] initPreferencesExplorer', source)
        self.assertIn('WQCacheCleanerViewController new', source)
        self.assertIn('/private/var/mobile/Containers/Shared/AppGroup', source)
        self.assertIn('/private/var/mobile/Containers/Data/PluginKitPlugin', source)
        self.assertIn('/private/var/containers/Data/InternalDaemon', source)
        self.assertIn('WQSystemGroupsViewController new', source)

    def test_system_data_is_opened_read_only(self):
        source = (ROOT / 'main.m').read_text()
        self.assertIn('System Data (read-only)', source)
        self.assertIn('((WQDirViewController *)target).readOnly = YES;', source)

    def test_access_diagnostics_are_read_only_and_non_inferential(self):
        source = (ROOT / 'main.m').read_text()
        self.assertIn('WQNeoAccessDiagnosticsViewController', source)
        self.assertIn('does not test write permission', source)
        self.assertIn('Not tested', source)
        self.assertIn('never claims write access', source)

    def test_github_ipa_workflow_runs_on_macos_and_uses_build_script(self):
        workflow = (ROOT / '.github' / 'workflows' / 'build-ipa.yml').read_text()
        self.assertIn('runs-on: macos-15', workflow)
        self.assertIn('run: bash ./build.sh', workflow)
        self.assertIn('actions/upload-artifact@v4', workflow)
        self.assertIn('NeoTweaks-build100.ipa', workflow)
        self.assertIn("neotweaks-v*", workflow)

    def test_readme_documents_manual_github_ipa_build_and_signing_limits(self):
        readme = (ROOT / 'README.md').read_text()
        self.assertIn('Build an IPA on GitHub', readme)
        self.assertIn('Actions → Build NeoTweaks IPA', readme)
        self.assertIn('ad-hoc-signed IPA', readme)
        self.assertIn('does not have your Apple signing identity', readme)

    def test_theme_and_icon_pack_ui_removed(self):
        source = (ROOT / 'main.m').read_text()
        self.assertNotIn('WQNeoThemePreviewViewController', source)
        self.assertNotIn('WQNeoThemeManagerViewController', source)
        self.assertNotIn('validateThemePacks', source)
        self.assertNotIn('beginIconImport', source)

if __name__ == '__main__':
    unittest.main()
