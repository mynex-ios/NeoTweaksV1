# NeoTweaks Build 98 status

This source build replaces the theme/icon-pack prototype UI with a hub over existing WQ Files capabilities. It reuses the upstream access layer and controllers; it does not add sandbox permissions or bypass iOS restrictions.

Included routes: App Data, Preferences Explorer (backup-first), Cache Cleaner, App Groups, Extension Data, Internal Daemons, System Groups, and read-only System Data when available. Existing file handling opens supported plist and SQLite files with the existing editors.

Validation performed in this environment:
- 25 Python regression/scope tests passed (localization, release metadata, update-source checks, and NeoTweaks scope checks).
- `plutil -lint Info.plist` passed.
- Full native preflight and iOS compilation were not run: this environment has no Xcode `xcrun` or Apple iOS SDK.
- No IPA has been built or device-tested.
