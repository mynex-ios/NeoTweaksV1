# NeoTweaks Build 100 status

Build 100 adds a GitHub Actions IPA build pipeline. It is intended to let the repository owner build on a GitHub-hosted macOS runner without installing Xcode locally.

Included:
- `.github/workflows/build-ipa.yml` runs on `macos-15` when manually dispatched or when a `neotweaks-v*` tag is pushed.
- The workflow runs the repository's `build.sh`, including its preflight and iOS arm64 compile/package/signature checks.
- Manual runs upload `NeoTweaks-build100.ipa` as the `NeoTweaks-build100-ipa` artifact.
- Tagged runs also attach the IPA to a GitHub Release.
- `CFBundleVersion` is now `100`.

Validation performed in this environment:
- NeoTweaks scope tests: 7 passed.
- Localization, release-policy and update-source tests: 21 passed.
- Full build tests were not run successfully here because this environment is Linux and the build script uses Apple-only `/usr/libexec/PlistBuddy`, Xcode SDKs and `codesign`. The GitHub workflow runs on macOS to provide those tools.
- No IPA was produced in this environment and no device test was performed.

Signing/access limitations:
- The existing build script uses ad-hoc signing with the entitlements in `entitlements.plist`.
- The workflow does not have an Apple signing identity or provisioning profile.
- A downloaded IPA may need to be re-signed with a compatible sideloading tool. Preserve the required App Group setup; actual worse_query access remains device/OS dependent.
- No additional sandbox permissions or system-write capabilities were added.
